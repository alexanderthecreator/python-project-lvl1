#!/usr/bin/env python3

from brain_games.game_modules.game_even import game


def main():
    print('Welcome to the Brain Games!')
    game()

if __name__ == '__main__':
    main()